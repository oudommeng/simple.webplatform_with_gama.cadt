<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1786526055461'>
  <properties size='10'>
    <property name='org.eclipse.equinox.p2.cache' value='C:\Users\User\Documents\02_git-project\simple.webplatform_with_gama.cadt\VU2'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='C:\Program Files\Gama'/>
    <property name='eclipse.touchpoint.launcherName' value='Gama'/>
    <property name='org.eclipse.equinox.p2.surrogate' value='true'/>
    <property name='org.eclipse.equinox.p2.cache.shared' value='C:\Program Files\Gama'/>
    <property name='org.eclipse.equinox.p2.configurationFolder' value='C:\Users\User\Documents\02_git-project\simple.webplatform_with_gama.cadt\VU2\.gama-headless-config'/>
    <property name='org.eclipse.equinox.p2.launcherConfiguration' value='C:\Users\User\Documents\02_git-project\simple.webplatform_with_gama.cadt\VU2\.gama-headless-config\eclipse.ini.ignored'/>
  </properties>
  <units size='12'>
    <unit id='SharedProfile_DefaultProfile' version='1.0.0.1751519520784' singleton='false' generation='2'>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Shared profile'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='SharedProfile_DefaultProfile' version='1.0.0.1751519520784'/>
      </provides>
      <requires size='269'>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.expressions&apos;, version(&apos;3.9.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help&apos;, version(&apos;3.10.400.v20240415-0528&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator&apos;, version(&apos;1.5.400.v20250129-0942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.library&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.cdatetime&apos;, version(&apos;1.5.0.202501071519&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.event&apos;, version(&apos;1.7.200.v20250129-1349&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.inject&apos;, version(&apos;7.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.orbit.xml-apis-ext&apos;, version(&apos;1.0.0.v20240917-0534&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.extension.maths&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.shell&apos;, version(&apos;1.1.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.identity&apos;, version(&apos;3.10.0.v20240812-1535&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.extension.pedestrian&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.di&apos;, version(&apos;1.5.500.v20250105-1208&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.variables&apos;, version(&apos;3.6.500.v20240702-1152&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sat4j.core&apos;, version(&apos;2.3.6.v20201214&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.simpleconfigurator&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.renderers.swt&apos;, version(&apos;0.16.700.v20250212-1224&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.urischeme&apos;, version(&apos;1.3.500.v20240913-1323&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.operations&apos;, version(&apos;2.7.500.v20250129-0944&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.upnp&apos;, version(&apos;1.2.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.console&apos;, version(&apos;3.14.200.v20240918-1457&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare&apos;, version(&apos;3.11.300.v20250120-0641&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.scr&apos;, version(&apos;2.2.12&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.builder&apos;, version(&apos;2.38.0.v20250226-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.tukaani.xz&apos;, version(&apos;1.10.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.promise&apos;, version(&apos;1.3.0.202212101352&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.resources&apos;, version(&apos;3.22.100.v20250206-1238&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.extension.network&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.annotation-api&apos;, version(&apos;2.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator.manipulator&apos;, version(&apos;2.3.400.v20250129-1118&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.position&apos;, version(&apos;1.0.1.201505202026&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.http.whiteboard&apos;, version(&apos;1.1.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.app&apos;, version(&apos;1.7.300.v20250130-0528&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher.eclipse&apos;, version(&apos;1.6.400.v20250203-0704&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.cli&apos;, version(&apos;1.9.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.feature.ui.experiment.feature.jar&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext&apos;, version(&apos;2.38.0.v20250226-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata&apos;, version(&apos;2.9.300.v20250129-0519&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.logging&apos;, version(&apos;1.2.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf&apos;, version(&apos;3.12.0.v20250111-0100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.reconciler.dropins&apos;, version(&apos;1.5.500.v20250129-1128&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.provisioning&apos;, version(&apos;1.2.0.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.concurrent&apos;, version(&apos;1.3.200.v20250130-0530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.directorywatcher&apos;, version(&apos;1.4.500.v20250129-0524&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.garbagecollector&apos;, version(&apos;1.3.500.v20250129-0521&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore&apos;, version(&apos;2.38.0.v20241018-1213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.text&apos;, version(&apos;3.14.300.v20250119-1501&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.cm&apos;, version(&apos;1.6.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.core&apos;, version(&apos;3.10.600.v20250120-0641&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ecore&apos;, version(&apos;2.38.0.v20250226-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.inject.jakarta.inject-api&apos;, version(&apos;2.0.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.commands&apos;, version(&apos;3.12.300.v20241229-1638&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.ui.editor&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.runtime&apos;, version(&apos;1.1.6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt.win32.win32.x86_64&apos;, version(&apos;3.129.0.v20250221-1734&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;slf4j.api&apos;, version(&apos;2.0.16&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.runtime&apos;, version(&apos;3.33.0.v20250206-0919&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare.core&apos;, version(&apos;3.8.700.v20250120-0641&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.commons&apos;, version(&apos;9.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.themes&apos;, version(&apos;1.2.2700.v20250122-1423&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.extension.stats&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.feature.ui.experiment.feature.group&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.ui.shared&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.hamcrest&apos;, version(&apos;3.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit&apos;, version(&apos;4.13.2.v20240929-1000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.log4j&apos;, version(&apos;1.2.26&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.ui.experiment&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi&apos;, version(&apos;3.23.0.v20250228-0640&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.ui&apos;, version(&apos;3.11.0.v20250120-0641&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.search&apos;, version(&apos;3.17.100.v20241218-0937&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions.supplier&apos;, version(&apos;0.17.700.v20250122-1648&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.registry&apos;, version(&apos;3.12.300.v20250129-1129&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.text&apos;, version(&apos;3.27.0.v20250211-0938&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt&apos;, version(&apos;0.15.500.v20241219-0802&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.extension.serialize&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.jobs&apos;, version(&apos;3.15.500.v20250204-0817&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.service.api&apos;, version(&apos;1.2.2.v20231218-2126&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt.theme&apos;, version(&apos;0.14.500.v20250213-1508&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.dependencies&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.smap&apos;, version(&apos;2.38.0.v20250226-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.extension.traffic&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.event&apos;, version(&apos;1.4.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.jna&apos;, version(&apos;5.16.0.v20241222-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.feature.extension.image.feature.jar&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions&apos;, version(&apos;0.18.300.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.net&apos;, version(&apos;1.5.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit&apos;, version(&apos;2.22.0.v20240604-0832&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.osgi.bundle.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.editors&apos;, version(&apos;3.19.100.v20250205-1448&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.annotations&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.feature.extension.image.feature.group&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.useradmin&apos;, version(&apos;1.1.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.notifications&apos;, version(&apos;0.7.300.v20240707-1119&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm&apos;, version(&apos;9.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.measurement&apos;, version(&apos;1.0.2.201802012109&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin.equinox&apos;, version(&apos;1.3.300.v20250201-0550&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.util&apos;, version(&apos;3.7.300.v20231104-1118&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.constants&apos;, version(&apos;1.18.0.v20241009-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk.scheduler&apos;, version(&apos;1.6.400.v20250129-1122&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.aries.spifly.dynamic.bundle&apos;, version(&apos;1.3.7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.antlr.runtime&apos;, version(&apos;3.2.0.v20230929-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.antlr.runtime&apos;, version(&apos;4.7.2.v20221112-0806&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extensionlocation&apos;, version(&apos;1.5.500.v20250129-0522&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.jarprocessor&apos;, version(&apos;1.3.500.v20250129-0523&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.cwt&apos;, version(&apos;1.1.0.202501071519&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.feature.core.feature.group&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ltk.core.refactoring&apos;, version(&apos;3.15.0.v20241206-0650&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.engine&apos;, version(&apos;2.10.400.v20250129-0520&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.activities&apos;, version(&apos;2.38.0.v20250226-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui&apos;, version(&apos;2.8.700.v20250129-1121&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.ui&apos;, version(&apos;2.24.0.v20240911-1027&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codetemplates.ui&apos;, version(&apos;2.38.0.v20250226-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolinggama.ui.application.product.application&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.property&apos;, version(&apos;1.10.300.v20240424-0444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench&apos;, version(&apos;1.17.0.v20250215-1931&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.preferences&apos;, version(&apos;3.11.300.v20250130-0533&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director&apos;, version(&apos;2.6.600.v20250129-0525&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolinggama.ui.application.product.executable.win32.win32.x86_64&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.ui.navigator&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.artifact.repository&apos;, version(&apos;1.5.600.v20250129-0528&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.feature.ui.editor.feature.jar&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.natives&apos;, version(&apos;1.5.500.v20250129-1123&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.search.core&apos;, version(&apos;3.16.400.v20241111-2025&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.browser&apos;, version(&apos;3.8.400.v20240915-0736&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.feature.ui.feature.group&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.common&apos;, version(&apos;3.20.0.v20250129-1348&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.logging&apos;, version(&apos;2.38.0.v20250226-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codetemplates&apos;, version(&apos;2.38.0.v20250226-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.metatype&apos;, version(&apos;1.4.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.feature.extensions.feature.group&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.addons.swt&apos;, version(&apos;1.5.600.v20241107-2150&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.feature.library.feature.jar&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer&apos;, version(&apos;5.1.103.v20230705-0614&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di&apos;, version(&apos;1.9.500.v20240606-1236&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator&apos;, version(&apos;3.13.0.v20250116-1250&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.eclipse&apos;, version(&apos;2.4.400.v20250129-1124&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.xml&apos;, version(&apos;1.0.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.feature.dependencies.feature.jar&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface&apos;, version(&apos;3.36.0.v20250129-1243&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.common&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.console&apos;, version(&apos;1.4.900.v20250130-0533&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.properties.tabbed&apos;, version(&apos;3.10.400.v20240915-2200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.bindings&apos;, version(&apos;0.14.500.v20241015-1729&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gaml.compiler&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.p2.reconciler.dropins&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.lib&apos;, version(&apos;2.38.0.v20250226-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.device&apos;, version(&apos;1.1.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.feature.core.feature.jar&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.util&apos;, version(&apos;9.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.feature.ui.dependencies.feature.jar&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.ibm.icu&apos;, version(&apos;76.1.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench3&apos;, version(&apos;0.17.400.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.feature.extensions.feature.jar&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ltk.ui.refactoring&apos;, version(&apos;3.13.500.v20250115-1455&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.ui.application.product.executable.win32.win32.x86_64.Gama&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.change&apos;, version(&apos;2.17.0.v20240604-0832&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views&apos;, version(&apos;3.12.500.v20240915-0736&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.commons-io&apos;, version(&apos;2.18.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.widgets&apos;, version(&apos;1.4.200.v20240801-0837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.extension.fipa&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bcutil&apos;, version(&apos;1.80.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.model.workbench&apos;, version(&apos;2.4.500.v20250215-1931&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.updatechecker&apos;, version(&apos;1.4.400.v20250129-1120&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.services&apos;, version(&apos;2.5.100.v20250131-1039&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.ui&apos;, version(&apos;2.25.0.v20241015-0644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.log&apos;, version(&apos;1.4.700.v20250207-1902&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench.texteditor&apos;, version(&apos;3.19.100.v20250206-1224&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.shared&apos;, version(&apos;2.38.0.v20250226-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolinggama.ui.application.product.ini.win32.win32.x86_64&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.equinox.launcher&apos;, version(&apos;1.6.1000.v20250227-1734&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.prefs&apos;, version(&apos;1.1.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator.resources&apos;, version(&apos;3.9.600.v20241218-1253&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench&apos;, version(&apos;3.135.0.v20250204-1142&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.feature.ui.feature.jar&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.bidi&apos;, version(&apos;1.5.200.v20250129-1129&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.annotations&apos;, version(&apos;1.8.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.component&apos;, version(&apos;1.5.1.202212101352&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolinggama.ui.application.product.config.win32.win32.x86_64&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filebuffers&apos;, version(&apos;3.8.400.v20250108-1526&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository&apos;, version(&apos;2.9.300.v20250212-0912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.tree.analysis&apos;, version(&apos;9.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common&apos;, version(&apos;2.41.0.v20241204-1554&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.contexts&apos;, version(&apos;1.13.100.v20250122-1647&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.extension.image&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filesystem&apos;, version(&apos;1.11.100.v20241022-0806&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher&apos;, version(&apos;1.9.400.v20250201-1219&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.services&apos;, version(&apos;3.12.200.v20241212-0858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt&apos;, version(&apos;3.129.0.v20250221-1734&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.commands&apos;, version(&apos;1.1.500.v20241015-1729&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.update.configurator&apos;, version(&apos;3.5.600.v20241215-0811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.feature.ui.editor.feature.group&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.css&apos;, version(&apos;1.18.0.v20241009-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.servlet-api&apos;, version(&apos;4.0.6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.databinding&apos;, version(&apos;1.15.300.v20240424-0444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.headless&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer&apos;, version(&apos;3.3.100.v20250115-0406&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.util&apos;, version(&apos;2.38.0.v20250226-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding&apos;, version(&apos;1.13.400.v20250122-0807&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.extension.database&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui&apos;, version(&apos;3.207.100.v20250103-1151&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.ui.application&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.core&apos;, version(&apos;0.14.500.v20240606-0949&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.transport.ecf&apos;, version(&apos;1.4.400.v20250129-1119&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.ide&apos;, version(&apos;3.17.200.v20231201-1637&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.wireadmin&apos;, version(&apos;1.0.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;a.jre.javase&apos;, version(&apos;21.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.extension.bdi&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.tree&apos;, version(&apos;9.7.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.core&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.feature.library.feature.group&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.aopalliance&apos;, version(&apos;1.0.0.v20230720-0728&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core&apos;, version(&apos;2.13.0.v20250129-0522&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.apache.felix.scr&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.guava.failureaccess&apos;, version(&apos;1.0.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin&apos;, version(&apos;2.3.300.v20250129-0943&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.processor&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.compatibility.state&apos;, version(&apos;1.2.1100.v20250129-0721&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codetemplates.ide&apos;, version(&apos;2.38.0.v20250226-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk&apos;, version(&apos;1.3.400.v20250129-1122&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.net&apos;, version(&apos;1.5.600.v20250124-0919&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.dialogs&apos;, version(&apos;1.6.0.v20250131-1354&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher.win32.win32.x86_64&apos;, version(&apos;1.2.1200.v20250212-0927&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd&apos;, version(&apos;2.20.0.v20240911-0848&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.logging&apos;, version(&apos;12.0.16&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.console&apos;, version(&apos;1.3.600.v20250118-1432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.emf.xpath&apos;, version(&apos;0.6.0.v20250215-1931&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide&apos;, version(&apos;3.22.500.v20250124-0833&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide.application&apos;, version(&apos;1.5.600.v20241021-1257&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ide&apos;, version(&apos;2.38.0.v20250226-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.core.runtime&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.swt&apos;, version(&apos;0.17.700.v20250123-0706&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata.repository&apos;, version(&apos;1.5.500.v20250129-0521&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.observable&apos;, version(&apos;1.13.300.v20240424-0444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui&apos;, version(&apos;2.38.0.v20250226-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.i18n&apos;, version(&apos;1.18.0.v20241009-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.event&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.ui.application.product.executable.win32.win32.x86_64&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.lib.macro&apos;, version(&apos;2.38.0.v20250226-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher&apos;, version(&apos;1.6.1000.v20250227-1734&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.jna.platform&apos;, version(&apos;5.16.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.forms&apos;, version(&apos;3.13.400.v20240905-1138&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.source.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.equinox.launcher.win32.win32.x86_64&apos;, version(&apos;1.2.1200.v20250212-0927&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bcprov&apos;, version(&apos;1.80.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.guava&apos;, version(&apos;33.4.0.jre&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security&apos;, version(&apos;1.4.500.v20250129-1350&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xmi&apos;, version(&apos;2.38.0.v20240721-0634&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.util&apos;, version(&apos;1.18.0.v20241009-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.function&apos;, version(&apos;1.2.0.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sat4j.pb&apos;, version(&apos;2.3.6.v20201214&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bcpg&apos;, version(&apos;1.80.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.command&apos;, version(&apos;1.1.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xmlgraphics&apos;, version(&apos;2.10.0.v20241009-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.ui.application.product&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolinggama.ui.application.product.configuration&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.feature.ui.dependencies.feature.group&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.progress&apos;, version(&apos;0.4.700.v20241015-1729&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.sshd.osgi&apos;, version(&apos;2.15.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.feature.dependencies.feature.group&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.extension.physics&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.ui.viewers&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.ui.display.java2d&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.lib&apos;, version(&apos;2.38.0.v20250226-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.services&apos;, version(&apos;1.6.500.v20250123-0754&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.core&apos;, version(&apos;3.22.100.v20250129-1642&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.contenttype&apos;, version(&apos;3.9.600.v20241001-1711&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.ui&apos;, version(&apos;1.4.400.v20250129-1347&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.org.eclipse.update.feature.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;gama.ui.display.opengl&apos;, version(&apos;2025.6.4&apos;)]' min='0'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='gama.feature.core.feature.group' version='2025.6.4' singleton='false'>
      <update id='gama.feature.core.feature.group' range='[0.0.0,2025.6.4)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Core plugins of GAMA'/>
        <property name='org.eclipse.equinox.p2.description' value='The core of the GAMA Modeling and Simulation Platform'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://gama-platform.org'/>
        <property name='org.eclipse.equinox.p2.provider' value='UMMISCO'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.gama'/>
        <property name='maven-artifactId' value='gama.feature.core'/>
        <property name='maven-version' value='2025.6.4'/>
        <property name='maven-type' value='eclipse-feature'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='gama.feature.core.feature.group' version='2025.6.4'/>
      </provides>
      <requires size='25'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.google.guava' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.operations' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.extension.traffic' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.extension.database' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.extension.network' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.util' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.xbase.lib' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.extension.maths' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.dependencies' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.core' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.headless' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gaml.compiler' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.annotations' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.processor' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.extension.stats' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.core.feature.jar' range='[2025.6.4,2025.6.4]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='http://www.example.com/license' url='http://www.example.com/license'>
          [Enter License Description here.]
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='gama.feature.dependencies.feature.group' version='2025.6.4' singleton='false'>
      <update id='gama.feature.dependencies.feature.group' range='[0.0.0,2025.6.4)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Dependencies of GAMA'/>
        <property name='org.eclipse.equinox.p2.description' value='[Enter Feature Description here.]'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.example.com/description'/>
        <property name='org.eclipse.equinox.p2.provider' value='UMMISCO'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.gama'/>
        <property name='maven-artifactId' value='gama.feature.dependencies'/>
        <property name='maven-version' value='2025.6.4'/>
        <property name='maven-type' value='eclipse-feature'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='gama.feature.dependencies.feature.group' version='2025.6.4'/>
      </provides>
      <requires size='115'>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.dependencies' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands' range='[3.12.300.v20241229-1638,3.12.300.v20241229-1638]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse' range='[2.4.400.v20250129-1124,2.4.400.v20250129-1124]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository' range='[1.5.600.v20250129-0528,1.5.600.v20250129-0528]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine' range='[2.10.400.v20250129-0520,2.10.400.v20250129-0520]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common' range='[2.41.0.v20241204-1554,2.41.0.v20241204-1554]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin' range='[2.3.300.v20250129-0943,2.3.300.v20250129-0943]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' range='[1.4.500.v20250129-1350,1.4.500.v20250129-1350]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector' range='[1.3.500.v20250129-0521,1.3.500.v20250129-0521]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository' range='[2.9.300.v20250212-0912,2.9.300.v20250212-0912]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='[2.3.400.v20250129-1118,2.3.400.v20250129-1118]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.operations' range='[2.7.500.v20250129-0944,2.7.500.v20250129-0944]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' range='[3.9.600.v20241001-1711,3.9.600.v20241001-1711]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.google.inject' range='[7.0.0,7.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.console' range='[1.3.600.v20250118-1432,1.3.600.v20250118-1432]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.macosx' range='[1.3.400.v20220812-1420,1.3.400.v20220812-1420]'>
          <filter>
            (&amp;(osgi.os=macosx)(osgi.ws=cocoa)(|(osgi.arch=x86)(osgi.arch=x86_64)))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare.core' range='[3.8.700.v20250120-0641,3.8.700.v20250120-0641]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor' range='[1.3.500.v20250129-0523,1.3.500.v20250129-0523]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filebuffers' range='[3.8.400.v20250108-1526,3.8.400.v20250108-1526]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.pb' range='[2.3.6.v20201214,2.3.6.v20201214]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property' range='[1.10.300.v20240424-0444,1.10.300.v20240424-0444]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' range='[3.12.300.v20250129-1129,3.12.300.v20250129-1129]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' range='[1.11.100.v20241022-0806,1.11.100.v20241022-0806]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox' range='[1.3.300.v20250201-0550,1.3.300.v20250201-0550]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' range='[3.15.500.v20250204-0817,3.15.500.v20250204-0817]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net' range='[1.5.600.v20250124-0919,1.5.600.v20250124-0919]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.core' range='[2.3.6.v20201214,2.3.6.v20201214]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi' range='[2.38.0.v20240721-0634,2.38.0.v20240721-0634]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher' range='[1.4.500.v20250129-0524,1.4.500.v20250129-0524]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher' range='[1.6.1000.v20250227-1734,1.6.1000.v20250227-1734]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables' range='[3.6.500.v20240702-1152,3.6.500.v20240702-1152]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' range='[3.9.400.v20240413-1529,3.9.400.v20240413-1529]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' range='[3.11.300.v20250130-0533,3.11.300.v20250130-0533]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore' range='[2.38.0.v20241018-1213,2.38.0.v20241018-1213]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata' range='[2.9.300.v20250129-0519,2.9.300.v20250129-0519]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.core.refactoring' range='[3.15.0.v20241206-0650,3.15.0.v20241206-0650]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='[3.22.100.v20250206-1238,3.22.100.v20250206-1238]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director' range='[2.6.600.v20250129-0525,2.6.600.v20250129-0525]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins' range='[1.5.500.v20250129-1128,1.5.500.v20250129-1128]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.macosx' range='[1.102.400.v20250130-0533,1.102.400.v20250130-0533]'>
          <filter>
            (&amp;(osgi.os=macosx)(osgi.ws=cocoa)(|(osgi.arch=x86)(osgi.arch=x86_64)))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable' range='[1.13.300.v20240424-0444,1.13.300.v20240424-0444]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator' range='[1.5.400.v20250129-0942,1.5.400.v20250129-0942]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding' range='[1.13.400.v20250122-0807,1.13.400.v20250122-0807]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation' range='[1.5.500.v20250129-0522,1.5.500.v20250129-0522]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' range='[3.20.0.v20250129-1348,3.20.0.v20250129-1348]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='[1.2.1300.v20250212-0927,1.2.1300.v20250212-0927]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx.x86_64' range='[1.2.1200.v20250212-0927,1.2.1200.v20250212-0927]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='[3.33.0.v20250206-0919,3.33.0.v20250206-0919]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository' range='[1.5.500.v20250129-0521,1.5.500.v20250129-0521]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' range='[1.7.300.v20250130-0528,1.7.300.v20250130-0528]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core' range='[2.13.0.v20250129-0522,2.13.0.v20250129-0522]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.cli' range='[1.9.0,1.9.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher' range='[1.9.400.v20250201-1219,1.9.400.v20250201-1219]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse' range='[1.6.400.v20250203-0704,1.6.400.v20250203-0704]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86_64' range='[1.2.1200.v20250212-0927,1.2.1200.v20250212-0927]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.edit' range='[2.22.0.v20240604-0832,2.22.0.v20240604-0832]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit' range='[4.13.2.v20240929-1000,4.13.2.v20240929-1000]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' range='[3.23.0.v20250228-0640,3.23.0.v20250228-0640]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.updatechecker' range='[1.4.400.v20250129-1120,1.4.400.v20250129-1120]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.transport.ecf' range='[1.4.400.v20250129-1119,1.4.400.v20250129-1119]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext' range='[2.38.0.v20250226-0658,2.38.0.v20250226-0658]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.activities' range='[2.38.0.v20250226-0658,2.38.0.v20250226-0658]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ecore' range='[2.38.0.v20250226-0658,2.38.0.v20250226-0658]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.smap' range='[2.38.0.v20250226-0658,2.38.0.v20250226-0658]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.util' range='[2.38.0.v20250226-0658,2.38.0.v20250226-0658]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.core' range='[3.10.600.v20250120-0641,3.10.600.v20250120-0641]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtend.lib' range='[2.38.0.v20250226-0658,2.38.0.v20250226-0658]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.xbase.lib' range='[2.38.0.v20250226-0658,2.38.0.v20250226-0658]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtend.lib.macro' range='[2.38.0.v20250226-0658,2.38.0.v20250226-0658]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.urischeme' range='[1.3.500.v20240913-1323,1.3.500.v20240913-1323]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.logging' range='[2.38.0.v20250226-0658,2.38.0.v20250226-0658]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.commands' range='[1.1.500.v20241015-1729,1.1.500.v20241015-1729]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.contexts' range='[1.13.100.v20250122-1647,1.13.100.v20250122-1647]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di' range='[1.9.500.v20240606-1236,1.9.500.v20240606-1236]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di.annotations' range='[1.8.400.v20240413-1529,1.8.400.v20240413-1529]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di.extensions' range='[0.18.300.v20240413-1529,0.18.300.v20240413-1529]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di.extensions.supplier' range='[0.17.700.v20250122-1648,0.17.700.v20250122-1648]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.services' range='[2.5.100.v20250131-1039,2.5.100.v20250131-1039]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.emf.xpath' range='[0.6.0.v20250215-1931,0.6.0.v20250215-1931]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.bidi' range='[1.5.200.v20250129-1129,1.5.200.v20250129-1129]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.event' range='[1.7.200.v20250129-1349,1.7.200.v20250129-1349]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf' range='[3.12.0.v20250111-0100,3.12.0.v20250111-0100]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer' range='[5.1.103.v20230705-0614,5.1.103.v20230705-0614]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.identity' range='[3.10.0.v20240812-1535,3.10.0.v20240812-1535]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.sun.jna' range='[5.16.0.v20241222-1200,5.16.0.v20241222-1200]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.sun.jna.platform' range='[5.16.0,5.16.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.logging' range='[1.2.0,1.2.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.batik.css' range='[1.18.0.v20241009-1200,1.18.0.v20241009-1200]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.batik.constants' range='[1.18.0.v20241009-1200,1.18.0.v20241009-1200]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.batik.i18n' range='[1.18.0.v20241009-1200,1.18.0.v20241009-1200]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.batik.util' range='[1.18.0.v20241009-1200,1.18.0.v20241009-1200]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.xmlgraphics' range='[2.10.0.v20241009-1200,2.10.0.v20241009-1200]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change' range='[2.17.0.v20240604-0832,2.17.0.v20240604-0832]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.concurrent' range='[1.3.200.v20250130-0530,1.3.200.v20250130-0530]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.core' range='[3.22.100.v20250129-1642,3.22.100.v20250129-1642]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.tukaani.xz' range='[1.10.0,1.10.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer' range='[3.3.100.v20250115-0406,3.3.100.v20250115-0406]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.command' range='[1.1.2,1.1.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.runtime' range='[1.1.6,1.1.6]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.scr' range='[2.2.12,2.2.12]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.shell' range='[1.1.4,1.1.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.sshd.osgi' range='[2.15.0,2.15.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state' range='[1.2.1100.v20250129-0721,1.2.1100.v20250129-0721]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util' range='[3.7.300.v20231104-1118,3.7.300.v20231104-1118]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd' range='[2.20.0.v20240911-0848,2.20.0.v20240911-0848]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.antlr.runtime' range='[4.7.2.v20221112-0806,4.7.2.v20221112-0806]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' range='[1.5.500.v20250129-1123,1.5.500.v20250129-1123]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.aopalliance' range='[1.0.0.v20230720-0728,1.0.0.v20230720-0728]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx.aarch64' range='[1.2.1200.v20250212-0927,1.2.1200.v20250212-0927]'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.configurator' range='[3.5.600.v20241215-0811,3.5.600.v20241215-0811]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.console' range='[1.4.900.v20250130-0533,1.4.900.v20250130-0533]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.log4j' range='[1.2.26,1.2.26]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='slf4j.api' range='[2.0.16,2.0.16]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='jakarta.inject.jakarta.inject-api' range='[2.0.1,2.0.1]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.dependencies.feature.jar' range='[2025.6.4,2025.6.4]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='http://www.example.com/license' url='http://www.example.com/license'>
          [Enter License Description here.]
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='gama.feature.extension.image.feature.group' version='2025.6.4' singleton='false'>
      <update id='gama.feature.extension.image.feature.group' range='[0.0.0,2025.6.4)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Image'/>
        <property name='org.eclipse.equinox.p2.description' value='This plug-in contains the &apos;image&apos; type present in GAML and associated operators.'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.example.com/description'/>
        <property name='org.eclipse.equinox.p2.provider' value='UMMISCO'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.gama'/>
        <property name='maven-artifactId' value='gama.feature.extension.image'/>
        <property name='maven-version' value='2025.6.4'/>
        <property name='maven-type' value='eclipse-feature'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='gama.feature.extension.image.feature.group' version='2025.6.4'/>
      </provides>
      <requires size='4'>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.core' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.dependencies' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.extension.image' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.extension.image.feature.jar' range='[2025.6.4,2025.6.4]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='http://www.example.com/license' url='http://www.example.com/license'>
          Plug-in: GPL v3 licence (GAMA licence)
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='gama.feature.extensions.feature.group' version='2025.6.4' singleton='false'>
      <update id='gama.feature.extensions.feature.group' range='[0.0.0,2025.6.4)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Standard Extensions to the Core of GAMA'/>
        <property name='org.eclipse.equinox.p2.description' value='Direct extensions to the core of GAMA'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://gama-platform.org'/>
        <property name='org.eclipse.equinox.p2.provider' value='UMMISCO, ESPACE-DEV, IRIT &amp; MIAT'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.gama'/>
        <property name='maven-artifactId' value='gama.feature.extensions'/>
        <property name='maven-version' value='2025.6.4'/>
        <property name='maven-type' value='eclipse-feature'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='gama.feature.extensions.feature.group' version='2025.6.4'/>
      </provides>
      <requires size='15'>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.core.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.extension.serialize' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.core' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.dependencies' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.extension.database' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.extension.fipa' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.extension.traffic' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.extension.bdi' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.extension.maths' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.extension.network' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.extension.serialize' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.extension.physics' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.extension.pedestrian' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.extensions.feature.jar' range='[2025.6.4,2025.6.4]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='http://www.example.com/license' url='http://www.example.com/license'>
          [Enter License Description here.]
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='gama.feature.library.feature.group' version='2025.6.4' singleton='false'>
      <update id='gama.feature.library.feature.group' range='[0.0.0,2025.6.4)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Models'/>
        <property name='org.eclipse.equinox.p2.description' value='The library of models of GAMA'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.gama-platform.org'/>
        <property name='org.eclipse.equinox.p2.provider' value='UMMISCO'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.gama'/>
        <property name='maven-artifactId' value='gama.feature.library'/>
        <property name='maven-version' value='2025.6.4'/>
        <property name='maven-type' value='eclipse-feature'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='gama.feature.library.feature.group' version='2025.6.4'/>
      </provides>
      <requires size='2'>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.library' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.library.feature.jar' range='[2025.6.4,2025.6.4]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='http://www.example.com/license' url='http://www.example.com/license'>
          [Enter License Description here.]
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='gama.feature.ui.dependencies.feature.group' version='2025.6.4' singleton='false'>
      <update id='gama.feature.ui.dependencies.feature.group' range='[0.0.0,2025.6.4)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='UI Dependencies of GAMA'/>
        <property name='org.eclipse.equinox.p2.description' value='[Enter Feature Description here.]'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.example.com/description'/>
        <property name='org.eclipse.equinox.p2.provider' value='UMMISCO'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.gama'/>
        <property name='maven-artifactId' value='gama.feature.ui.dependencies'/>
        <property name='maven-version' value='2025.6.4'/>
        <property name='maven-type' value='eclipse-feature'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='gama.feature.ui.dependencies.feature.group' version='2025.6.4'/>
      </provides>
      <requires size='65'>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.dependencies.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.ui.application' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt' range='[3.129.0.v20250221-1734,3.129.0.v20250221-1734]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views.log' range='[1.4.700.v20250207-1902,1.4.700.v20250207-1902]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench' range='[3.135.0.v20250204-1142,3.135.0.v20250204-1142]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide' range='[3.22.500.v20250124-0833,3.22.500.v20250124-0833]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface' range='[3.36.0.v20250129-1243,3.36.0.v20250129-1243]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator.resources' range='[3.9.600.v20241218-1253,3.9.600.v20241218-1253]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ui' range='[2.8.700.v20250129-1121,2.8.700.v20250129-1121]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.ui.refactoring' range='[3.13.500.v20250115-1455,3.13.500.v20250115-1455]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86_64' range='[3.129.0.v20250221-1734,3.129.0.v20250221-1734]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views.properties.tabbed' range='[3.10.400.v20240915-2200,3.10.400.v20240915-2200]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.browser' range='[3.8.400.v20240915-0736,3.8.400.v20240915-0736]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text' range='[3.27.0.v20250211-0938,3.27.0.v20250211-0938]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator' range='[3.13.0.v20250116-1250,3.13.0.v20250116-1250]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.edit.ui' range='[2.25.0.v20241015-0644,2.25.0.v20241015-0644]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64' range='[3.129.0.v20250221-1734,3.129.0.v20250221-1734]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.texteditor' range='[3.19.100.v20250206-1224,3.19.100.v20250206-1224]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' range='[3.207.100.v20250103-1151,3.207.100.v20250103-1151]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms' range='[3.13.400.v20240905-1138,3.13.400.v20240905-1138]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text' range='[3.14.300.v20250119-1501,3.14.300.v20250119-1501]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cocoa' range='[1.3.200.v20240309-0857,1.3.200.v20240309-0857]'>
          <filter>
            (&amp;(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.ui' range='[2.24.0.v20240911-1027,2.24.0.v20240911-1027]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide.application' range='[1.5.600.v20241021-1257,1.5.600.v20241021-1257]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64' range='[3.129.0.v20250221-1734,3.129.0.v20250221-1734]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.editors' range='[3.19.100.v20250205-1448,3.19.100.v20250205-1448]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views' range='[3.12.500.v20240915-0736,3.12.500.v20240915-0736]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.ui' range='[1.4.400.v20250129-1347,1.4.400.v20250129-1347]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.console' range='[3.14.200.v20240918-1457,3.14.200.v20240918-1457]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ui.sdk' range='[1.3.400.v20250129-1122,1.3.400.v20250129-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ui.sdk.scheduler' range='[1.6.400.v20250129-1122,1.6.400.v20250129-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ui' range='[2.38.0.v20250226-0658,2.38.0.v20250226-0658]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ui.codetemplates' range='[2.38.0.v20250226-0658,2.38.0.v20250226-0658]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ui.codetemplates.ui' range='[2.38.0.v20250226-0658,2.38.0.v20250226-0658]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ui.shared' range='[2.38.0.v20250226-0658,2.38.0.v20250226-0658]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ide' range='[2.38.0.v20250226-0658,2.38.0.v20250226-0658]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.ui' range='[3.11.0.v20250120-0641,3.11.0.v20250120-0641]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net' range='[1.5.400.v20240413-1529,1.5.400.v20240413-1529]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ui.codetemplates.ide' range='[2.38.0.v20250226-0658,2.38.0.v20250226-0658]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench' range='[1.17.0.v20250215-1931,1.17.0.v20250215-1931]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench' range='[2.4.500.v20250215-1931,2.4.500.v20250215-1931]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.bindings' range='[0.14.500.v20241015-1729,0.14.500.v20241015-1729]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.core' range='[0.14.500.v20240606-0949,0.14.500.v20240606-0949]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt' range='[0.15.500.v20241219-0802,0.15.500.v20241219-0802]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.theme' range='[0.14.500.v20250213-1508,0.14.500.v20250213-1508]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.di' range='[1.5.500.v20250105-1208,1.5.500.v20250105-1208]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.dialogs' range='[1.6.0.v20250131-1354,1.6.0.v20250131-1354]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.ide' range='[3.17.200.v20231201-1637,3.17.200.v20231201-1637]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.services' range='[1.6.500.v20250123-0754,1.6.500.v20250123-0754]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.widgets' range='[1.4.200.v20240801-0837,1.4.200.v20240801-0837]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.addons.swt' range='[1.5.600.v20241107-2150,1.5.600.v20241107-2150]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt' range='[0.16.700.v20250212-1224,0.16.700.v20250212-1224]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.swt' range='[0.17.700.v20250123-0706,0.17.700.v20250123-0706]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench3' range='[0.17.400.v20240321-1245,0.17.400.v20240321-1245]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding' range='[1.15.300.v20240424-0444,1.15.300.v20240424-0444]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.notifications' range='[0.7.300.v20240707-1119,0.7.300.v20240707-1119]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.themes' range='[1.2.2700.v20250122-1423,1.2.2700.v20250122-1423]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt.cocoa' range='[0.14.400.v20240525-0701,0.14.400.v20240525-0701]'>
          <filter>
            (&amp;(osgi.os=macosx)(osgi.ws=cocoa)(|(osgi.arch=aarch64)(osgi.arch=x86_64)))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.aarch64' range='[3.129.0.v20250221-1734,3.129.0.v20250221-1734]'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help' range='[3.10.400.v20240415-0528,3.10.400.v20240415-0528]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.search' range='[3.17.100.v20241218-0937,3.17.100.v20241218-0937]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare' range='[3.11.300.v20250120-0641,3.11.300.v20250120-0641]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.builder' range='[2.38.0.v20250226-0658,2.38.0.v20250226-0658]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.aarch64' range='[3.129.0.v20250221-1734,3.129.0.v20250221-1734]'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.ui.dependencies.feature.jar' range='[2025.6.4,2025.6.4]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='http://www.example.com/license' url='http://www.example.com/license'>
          [Enter License Description here.]
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='gama.feature.ui.editor.feature.group' version='2025.6.4' singleton='false'>
      <update id='gama.feature.ui.editor.feature.group' range='[0.0.0,2025.6.4)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='UI Components for designing models in  GAMA'/>
        <property name='org.eclipse.equinox.p2.description' value='The UI Components for designing models in  GAMA'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://gama-platform.org'/>
        <property name='org.eclipse.equinox.p2.provider' value='UMMISCO'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.gama'/>
        <property name='maven-artifactId' value='gama.feature.ui.editor'/>
        <property name='maven-version' value='2025.6.4'/>
        <property name='maven-type' value='eclipse-feature'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='gama.feature.ui.editor.feature.group' version='2025.6.4'/>
      </provides>
      <requires size='36'>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.ui.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gaml.compiler' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ui' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ui.shared' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.builder' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ui.codetemplates.ui' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.core' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.antlr.runtime' range='3.2.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.ui.shared' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.ui.application' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.dependencies' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.headless' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator.resources' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.ui' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.core.refactoring' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.ui.refactoring' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.google.guava' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='3.11.1'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' range='3.107.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.editors' range='3.9.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text' range='3.10.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.browser' range='3.4.300'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.ui.editor' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.ui.navigator' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.ui.viewers' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.ui.editor.feature.jar' range='[2025.6.4,2025.6.4]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='http://www.example.com/license' url='http://www.example.com/license'>
          [Enter License Description here.]
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='gama.feature.ui.experiment.feature.group' version='2025.6.4' singleton='false'>
      <update id='gama.feature.ui.experiment.feature.group' range='[0.0.0,2025.6.4)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='UI Components for running experiments in  GAMA'/>
        <property name='org.eclipse.equinox.p2.description' value='The UI components for running experiments in GAMA'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://gama-platform.org'/>
        <property name='org.eclipse.equinox.p2.provider' value='UMMISCO'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.gama'/>
        <property name='maven-artifactId' value='gama.feature.ui.experiment'/>
        <property name='maven-version' value='2025.6.4'/>
        <property name='maven-type' value='eclipse-feature'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='gama.feature.ui.experiment.feature.group' version='2025.6.4'/>
      </provides>
      <requires size='23'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.dependencies' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.core' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' range='3.107.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='3.11.1'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.ui.shared' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.ui.application' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.console' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.contexts' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.google.guava' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.annotations' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.ui.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.ui.display.java2d' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.ui.experiment' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.ui.display.opengl' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.ui.experiment.feature.jar' range='[2025.6.4,2025.6.4]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='http://www.example.com/license' url='http://www.example.com/license'>
          [Enter License Description here.]
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='gama.feature.ui.feature.group' version='2025.6.4' singleton='false'>
      <update id='gama.feature.ui.feature.group' range='[0.0.0,2025.6.4)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Common UI Components of GAMA'/>
        <property name='org.eclipse.equinox.p2.description' value='The common UI components of GAMA'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://gama-platform.org'/>
        <property name='org.eclipse.equinox.p2.provider' value='UMMISCO'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.gama'/>
        <property name='maven-artifactId' value='gama.feature.ui'/>
        <property name='maven-version' value='2025.6.4'/>
        <property name='maven-type' value='eclipse-feature'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='gama.feature.ui.feature.group' version='2025.6.4'/>
      </provides>
      <requires size='37'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.operations' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide.application' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' range='3.107.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide' range='3.11.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench' range='1.3.1'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.core' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.google.guava' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.services' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.contexts' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.theme' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt' range='0.13.1100'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.addons.swt' range='1.3.1100'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt' range='0.14.1300'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.swt' range='0.14.1100'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.core' range='0.13.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.dependencies' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.console' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.annotations' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.editors' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.ui.application' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.ui.shared' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.ui.feature.jar' range='[2025.6.4,2025.6.4]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='http://www.example.com/license' url='http://www.example.com/license'>
          [Enter License Description here.]
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='gama.ui.application.product' version='2025.6.4'>
      <update id='gama.ui.application.product' range='0.0.0' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='Gama'/>
        <property name='org.eclipse.equinox.p2.type.product' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='gama.ui.application.product' version='2025.6.4'/>
      </provides>
      <requires size='15'>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.core.feature.group' range='2025.6.4'>
          <filter>
            (|(gama.ui.application.product.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.ui.experiment.feature.group' range='2025.6.4'>
          <filter>
            (|(gama.ui.application.product.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.ui.editor.feature.group' range='2025.6.4'>
          <filter>
            (|(gama.ui.application.product.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.ui.feature.group' range='2025.6.4'>
          <filter>
            (|(gama.ui.application.product.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.extensions.feature.group' range='2025.6.4'>
          <filter>
            (|(gama.ui.application.product.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.extension.image.feature.group' range='2025.6.4'>
          <filter>
            (|(gama.ui.application.product.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.ui.dependencies.feature.group' range='2025.6.4'>
          <filter>
            (|(gama.ui.application.product.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.dependencies.feature.group' range='2025.6.4'>
          <filter>
            (|(gama.ui.application.product.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='gama.feature.library.feature.group' range='2025.6.4'>
          <filter>
            (|(gama.ui.application.product.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggama.ui.application.product.application' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggama.ui.application.product.configuration' range='[2025.6.4,2025.6.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
        <required namespace='osgi.ee' name='JavaSE' range='0.0.0'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <licenses size='1'>
        <license uri='https://www.gnu.org/licenses/gpl-3.0.html' url='https://www.gnu.org/licenses/gpl-3.0.html'>

        </license>
      </licenses>
    </unit>
    <unit id='gama.ui.application.product.executable.win32.win32.x86_64' version='2025.6.4'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='gama.ui.application.product.executable.win32.win32.x86_64' version='2025.6.4'/>
        <provided namespace='toolinggama.ui.application.product' name='gama.ui.application.product.executable' version='2025.6.4'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86_64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='gama.ui.application.product.executable.win32.win32.x86_64' version='2025.6.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
  </units>
  <iusProperties size='12'>
    <iuProperties id='SharedProfile_DefaultProfile' version='1.0.0.1751519520784'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='gama.feature.core.feature.group' version='2025.6.4'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='gama.feature.dependencies.feature.group' version='2025.6.4'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='gama.feature.extension.image.feature.group' version='2025.6.4'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='gama.feature.extensions.feature.group' version='2025.6.4'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='gama.feature.library.feature.group' version='2025.6.4'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='gama.feature.ui.dependencies.feature.group' version='2025.6.4'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='gama.feature.ui.editor.feature.group' version='2025.6.4'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='gama.feature.ui.experiment.feature.group' version='2025.6.4'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='gama.feature.ui.feature.group' version='2025.6.4'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='gama.ui.application.product' version='2025.6.4'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='gama.ui.application.product.executable.win32.win32.x86_64' version='2025.6.4'>
      <properties size='3'>
        <property name='unzipped|@artifact|/home/runner/work/gama/gama/gama.product/target/products/gama.ui.application.product/win32/win32/x86_64' value='/home/runner/work/gama/gama/gama.product/target/products/gama.ui.application.product/win32/win32/x86_64/Gamac.exe|/home/runner/work/gama/gama/gama.product/target/products/gama.ui.application.product/win32/win32/x86_64/Gama.exe|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
